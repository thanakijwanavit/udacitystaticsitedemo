Plese check out report.md which includes all the information regarding the deployment

images and report can also be accessed here
https://github.com/thanakijwanavit/udacitystaticsitedemo/blob/master/report.md

Endpoint for cloudfront
http://d17qdrfwc28fiq.cloudfront.net/index.html